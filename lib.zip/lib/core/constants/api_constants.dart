abstract final class ApiConstants {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:5000/api',
  );

  static const Duration timeout = Duration(seconds: 20);

  static String get realtimeUrl =>
      baseUrl.endsWith('/api') ? baseUrl.substring(0, baseUrl.length - 4) : baseUrl;

  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String session = '/session';

  static const String canteens = '/canteens';
  static const String offices = '/offices';
  static const String orders = '/orders';
  static const String publicOrders = '/public/orders';
  static const String account = '/account';

  static const String pendingOwners = '/admin/owners/pending';
  static const String owners = '/admin/owners';
  static const String adminOverview = '/admin/owners/overview';
}
